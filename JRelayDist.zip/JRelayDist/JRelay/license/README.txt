xml-commons/README.txt $Id: README.txt,v 1.1 2002/01/31 23:42:49 curcuru Exp $


HEAR YE, HEAR YE!


Software and documentation in this repository are covered under 
a number of different licenses.


Most files under xml-commons/java/external/ are covered 
under their respective LICENSE.*.txt files; see the matching 
README.*.txt files for descriptions.

Note that xml-commons/java/external/build.xml and 
xml-commons/java/external/src/manifest.commons are 
both covered under the Apache Software License.


All files not otherwise noted are covered under the 
Apache Software License in LICENSE.txt including all 
files under xml-commons/java/src
